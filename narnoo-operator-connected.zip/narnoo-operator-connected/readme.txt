=== Narnoo Operator Connected ===
Contributors: Narnoo
Donate link: 
Tags: Tourism, Media, Web Service, Travel, Narnoo
Requires at least: 3.3
Tested up to: 4.9.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Narnoo operator connected plugin allows a tourism business to manage third party products on their site.

== Description ==

The Narnoo operator connected plugin allows a tourism business to manage third party products on their site. More to come....

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. This plugin requires the Narnoo Operator's plugin

== Frequently asked questions ==

How to I get my Narnoo APP keys?

You can retrieve your APP keys from your account on Narnoo.com. Simply log into your account and go to the My Account -> View Applications menu option. From here you can either create or view existing key pairs.

== Screenshots ==

1. This screen shot shows you how you can see the tourism distributor's that are following your product media.
2. This screen shot shows you how you can interact with your images hosted on Narnoo.com. You can download the high resolution version, add the image to an album or delete the image from Narnoo.com
3.This screen shot shows you how you can interact with your videos hosted on Narnoo.com. You can download the high definition version or delete the video from Narnoo.com.
4. This screen shot shows you the short code menu option. We have 4 different image display options, 1 video display option and a brochure display option. All are easily embedded using the Narnoo short code menu.
5. This screen shot is an example of the slider image gallery.
6. All images have a large image file that is displayed in an lightbox. 

== Changelog ==

14-03-18: Initial release.

== Upgrade notice ==

No updates to date